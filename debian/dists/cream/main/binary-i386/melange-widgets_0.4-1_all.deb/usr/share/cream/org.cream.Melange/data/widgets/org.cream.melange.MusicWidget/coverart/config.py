import os

COVER_ART_BASE_DIR = os.path.expanduser('~/.cache/media-art')
LASTFM_API_KEY = '2f63459bcb2578a277c5cf5ec4ca62f7'
