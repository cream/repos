from players.banshee import Banshee
from players.rhythmbox import Rhythmbox
