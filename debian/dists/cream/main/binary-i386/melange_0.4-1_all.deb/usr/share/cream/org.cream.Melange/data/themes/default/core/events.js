var Widget = new Class({
    Implements: Events
    });

var events = new Widget();
